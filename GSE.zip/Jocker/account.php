<?php 
    session_start();
    include('./dbconnection.php');
    
 if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Account";
    $email = @$_SESSION['loggedUser'];
    
    // Query to retrieve booking details
    $getUserQuery =  "SELECT * FROM users WHERE email = '$email'";
    $user = $conn->query($getUserQuery);

    if(isset($_POST['updateUser'])){
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $row = $user->fetch_assoc();
        $uid = $row['userId'];

        if($row['firstname'] == $firstname && $row['lastname'] == $lastname && $row['email'] == $email && $row['phoneNumber'] == $phone){
             header("location:account.php?nothing=No Info to Update!");
        }else{
            $userUpdateQuery = "UPDATE users SET firstname = '$firstname', lastname = '$lastname', email = '$email', phoneNumber = '$phone' WHERE userId = '$uid'";
            $updatedInfo = $conn->query($userUpdateQuery);
            if($updatedInfo){
                 $_SESSION['loggedUser'] = $email;
                header("location:account.php?success=Updated Successfully");
            }
            else{
                 header("location:account.php?error=An Error Occurred. Try Again!");
            }
        }
        
    }
    elseif(isset($_POST['updatePassword'])){
        $row = $user->fetch_assoc();
        $uId = $row['userId'];
        $currentPassword = md5($_POST['currentPassword']);
        $newPassword = md5($_POST['newPassword']);
        $confirmPassword = md5($_POST['confirmPassword']);

        if($currentPassword != $row['password']){
              header("location:account.php?passError=Current Password is Invalid!");
        }
       elseif($newPassword != $confirmPassword){
              header("location:account.php?passError=The two passwords do not match!");
        }elseif($newPassword == $row['password']){
             header("location:account.php?repeat=New Password and the current password can't match!");
        }
        elseif($currentPassword == $row['password']){
            $passQuery = "UPDATE users SET password = '$newPassword' WHERE userId='$uId'";
            $passChanged = $conn->query($passQuery);
            if($passChanged){
                header("location:account.php?passSuccess=Passwords changed!");
            }else{
                 header("location:account.php?passError=An Error Occurred. Try Again!");
            }
        }
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/account.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="mainContainer">
        <h1 class="title">Account</h1>
        <div class="parent">
            <?php if($row = $user->fetch_assoc()): ?>
            <div class="left">
                <h2>User Information</h2>

                <form method="POST">
                    <?php if(@$_GET['nothing']):?>
                    <p class="info"><?php echo @$_GET['nothing'] ?></p>
                    <?php elseif(@$_GET['success']):?>
                    <p class="success"><?php echo @$_GET['success'] ?></p>
                    <?php elseif(@$_GET['error']):?>
                    <p class="error"><?php echo @$_GET['error'] ?></p>
                    <?php endif ?>
                    <label>FirstName</label>
                    <input required type="text" name="firstname" value="<?php echo @$row['firstname']?>">
                    <label>LastName</label>
                    <input required type="text" name="lastname" value="<?php echo @$row['lastname']?>">
                    <label>Email</label>
                    <input required type="email" name="email" value="<?php echo @$row['email']?>">
                    <label>Phone Number</label>
                    <input required type="text" name="phone" value="<?php echo @$row['phoneNumber']?>">
                    <input type="submit" name="updateUser" class="btndark" value="UPDATE">
                </form>

            </div>
            <div class="right">
                <h2>Password Management</h2>
                <form method="POST">
                    <?php if(@$_GET['repeat']):?>
                    <p class="info"><?php echo @$_GET['repeat'] ?></p>
                    <?php elseif(@$_GET['passSuccess']):?>
                    <p class="success"><?php echo @$_GET['passSuccess'] ?></p>
                    <?php elseif(@$_GET['passError']):?>
                    <p class="error"><?php echo @$_GET['passError'] ?></p>
                    <?php endif ?>
                    <label>Current Password</label>
                    <input min="6" required type="password" name="currentPassword" placeholder="Your Current Password">
                    <label>New Password</label>
                    <input min="6" required type="password" name="newPassword" placeholder="New Password">
                    <label>Confirm Password</label>
                    <input min="6" required type="password" name="confirmPassword" placeholder="Repeat New Password">

                    <input min="6" type="submit" name="updatePassword" class="btndark" value="UPDATE">
                </form>
            </div>
            <?php endif ?>
        </div>

    </div>
</body>

</html>
<?php }else{
    header('location: ./login.php');
} ?>