<?php 
define('API_KEY','CbGNJRgyuTt');
?>