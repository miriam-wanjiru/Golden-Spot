<?php 
    session_start();
    include('./dbconnection.php');
    //  if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Event Details";
    $eId = @$_GET['id'];
    $email = @$_SESSION['loggedUser'];
    $getEventQuery =  "SELECT * FROM events WHERE eventId = '$eId' AND isActive = 1";
    $events = $conn->query($getEventQuery);
    $getVenueQuery =  "SELECT * FROM venue WHERE isActive = 1";
    $venues = $conn->query($getVenueQuery);
    $getEntQuery =  "SELECT * FROM entertainment WHERE isActive = 1";
    $entertainments = $conn->query($getEntQuery);
    $userQ =  "SELECT userId FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $userQ);

     $length = 8; // Specify the desired length of the random string
        $bId = bin2hex(random_bytes($length / 2));
  
// Check if the query executed successfully
if ($result !== false) {
    // Check if a matching record was found
    if (mysqli_num_rows($result) > 0) {
        // Fetch the userId from the result set
       
        $row = mysqli_fetch_assoc($result);
        $userId = $row['userId'];
       

    if(isset($_POST['book'])){
        $bookingId = $_POST['bId'];
        $venueId = $_POST['venue'];
        $entertainmentId = $_POST['entertainment'];
        $themeColor = $_POST['theme'];
        $eventTime = date('Y-m-d', strtotime($_POST['period']));
        $info = $_POST['info'];
        $isPaid = 0;
        $eId = $_POST['evId'];

        $bookingsQuery = "INSERT INTO 
        bookings(bookingId,userId,eventTime,eventId,venueId,entId,info,theme,isPaid)
        VALUES('$bookingId','$userId','$eventTime','$eId','$venueId','$entertainmentId','$info','$themeColor','$isPaid')";

        $booked = mysqli_query($conn, $bookingsQuery);

// Check if the query executed successfully
    if ($booked) {
    // Retrieve the auto-incremented bookingId
    header("location:checkout.php?id=$bookingId");

} else {
    ?><script>
alert("Error creating booking");
</script><?php
}

    }    }}
   
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/eventDetails.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="mainContainer">
        <?php while ($row = $events->fetch_assoc()): ?>
        <div class="eventContainer">
            <div class="eventLeft">
                <div class="eventDetails">
                    <h1><?php echo $row['title']; ?></h1>
                    <h4>Ksh.<?php echo $row['price']; ?> + Venue Price + Entertainment Price</h4>
                </div>
                <div class="eventImage">
                    <img src="./admin/uploads/<?= $row['coverImage'] ?>" alt="">
                </div>
                <div class="desc">
                    <p><?php echo $row['descriptions']; ?></p>
                </div>
            </div>
            <div class="eventRight">

                <div class="form">
                    <form action="eventDetails.php" method="POST">
                        <input hidden type="text" value="<?php echo @$bId ?>" name="bId">
                        <input hidden type="text" value="<?php echo @$_GET['id'] ?>" name="evId">
                        <label>
                            Choose Venue
                        </label>
                        <select name="venue" id="" required>
                            <option value=""></option>
                            <?php while ($row = $venues->fetch_assoc()): ?>
                            <option value="<?php echo $row['venueId']?>">
                                <?php echo $row['title'] . " (". $row['make'] . ") in " . $row['located']. " for Ksh." . $row['price'] ; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        <label>
                            Choose Entertainment
                        </label>
                        <select name="entertainment" id="" required>
                            <option value=""></option>
                            <?php while ($row = $entertainments->fetch_assoc()): ?>
                            <option value="<?php echo $row['entId']?>">
                                <?php echo $row['deejay'] . " and " . $row['mc']. " from " . $row['title'] . " for Ksh." . $row['price'] ; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        <label>Date</label>
                        <input type="date" name="period" min="<?php echo date('Y-m-d'); ?>" placeholder="Color" id=""
                            required>
                        <label>Event Theme Color</label>
                        <input class="color" type="color" name="theme" placeholder="Color" id="" required>
                        <label>
                            Message
                        </label>
                        <textarea cols="8" rows="8" name="info" placeholder="Write a massage for the Admin..."
                            required></textarea>
                        <?php if(@$_SESSION['loggedUser']){?>
                        <button type="submit" name="book" class="btndark">BOOK</button>
                        <?Php } else {
                            ?> <a href="./login.php" name="book" class="btndark">LOGIN TO PROCEED</a> <?php
                           } ?>
                    </form>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

</body>

</html>
<!-- <?php 
    // }else{
    //      header("location:index.php");
    // }
    ?> -->