<?php 
    session_start();
    include('./dbconnection.php');
    include('config.php');

    $_SESSION['title'] = "Golden Spot - Checkout";
    $bId = $_GET['id'];
    $email = @$_SESSION['loggedUser'];

    // Query to retrieve booking details
    $getBookingQuery =  "SELECT bookings.*, events.coverImage, events.title AS eventTitle,events.price AS eventPrice, events.coverImage, venue.price AS venuePrice,venue.title AS venueTitle, venue.located, venue.make, venue.capacity, users.phoneNumber, entertainment.title AS entTitle, entertainment.price AS entPrice, entertainment.deejay, entertainment.mc
        FROM bookings
        INNER JOIN events ON bookings.eventId = events.eventId
        INNER JOIN venue ON bookings.venueId = venue.venueId
        INNER JOIN users ON bookings.userId = users.userId
        INNER JOIN entertainment ON bookings.entId = entertainment.entId 
        WHERE bookingId = '$bId'";
    $booking = $conn->query($getBookingQuery);

    if($booking) {

        // Query to retrieve user ID from email
        $userQ =  "SELECT userId FROM users WHERE email = '$email'";
        $result = mysqli_query($conn, $userQ);
    }

    if(isset($_POST['pay'])) {
        date_default_timezone_set('Africa/Nairobi');
    
        # access token
        $consumerKey = 'NGxXNfmGAcKHAS6joYMwyy3xvPqkSmS0vvXwKzuHvcZPNsT2';
        $consumerSecret = 'mbzGKUrZNFPWFGRDdTfMCG51aqVGyC2AH3WzzzarQ1Fe2ZIc0EGsDBqIAoENttXO';
    
        # define the variables
        $BusinessShortCode = '174379';
        $Passkey = 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919';  
    
        $PartyA = $_POST['phone']; // This is your phone number, 
        $PartyA = ltrim($PartyA, '0');
        $PartyA = '254' . $PartyA;
        $AccountReference = '2255';
        $TransactionDesc = 'Test Payment';
        $Amount = $_POST['amount'];
        $bookId = $_POST['bookingId'];
    
        $Timestamp = date('YmdHis');    
        $Password = base64_encode($BusinessShortCode.$Passkey.$Timestamp);
    
        $headers = ['Content-Type:application/json; charset=utf8'];
    
        $access_token_url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
        $initiate_url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
    
        $CallBackURL = 'https://morning-basin-87523.herokuapp.com/callback_url.php';  
    
        $curl = curl_init($access_token_url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($curl, CURLOPT_HEADER, FALSE);
        curl_setopt($curl, CURLOPT_USERPWD, $consumerKey.':'.$consumerSecret);
        $result = curl_exec($curl);
        $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $result = json_decode($result);
        $access_token = $result->access_token;  
        curl_close($curl);
    
        $stkheader = ['Content-Type:application/json','Authorization:Bearer '.$access_token];
    
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $initiate_url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $stkheader); //setting custom header
    
        $curl_post_data = array(
            'BusinessShortCode' => $BusinessShortCode,
            'Password' => $Password,
            'Timestamp' => $Timestamp,
            'TransactionType' => 'CustomerPayBillOnline',
            'Amount' => $Amount,
            'PartyA' => $PartyA,
            'PartyB' => $BusinessShortCode,
            'PhoneNumber' => $PartyA,
            'CallBackURL' => $CallBackURL,
            'AccountReference' => $AccountReference,
            'TransactionDesc' => $TransactionDesc
        );
    
        $data_string = json_encode($curl_post_data);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        $curl_response = curl_exec($curl);
        curl_close($curl);
    
        // Check for errors in the curl response
        if($curl_response === false) {
            $response_message = "Failed to initiate transaction";
        } else {
            $response_message = "Transaction initiated successfully";
        }
    
        // Encode the response message
        $response_message = urlencode($response_message);
    
        // Redirect with the response message
        header("Location:http://localhost/goldenspot/checkout.php?id=$bookId&response=$response_message");
        exit;
    }
    ?>
    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/checkout.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="mainContainer">
        <div class="parent">
            <?php if($booking):
                    $row = $booking->fetch_assoc() ?>
            <div class="left">
                <span>
                    <h1>Checkout</h1>
                    <h2>Booking ID #<?php echo $_GET['id']; ?></h2>
                </span>

                <!-- Event Details -->


                <div class="wrapper">
                    <div class="imgContainer">
                        <img src="./admin/uploads/<?php echo $row['coverImage'] ?>" alt="">
                    </div>
                    <div class="event">
                        <h2>Event Details</h2>
                        <h3>Event: <?php echo $row['eventTitle'] ? $row['eventTitle'] : "N/A" ?></h3>
                        <h4>Date: <?php echo $row['eventTime']?></h4>
                        <h5>Ksh.<?php echo $row['eventPrice'] ?></h5>
                    </div>
                    <div class="venue">
                        <!-- Venue Details -->
                        <h2>Venue Details</h2>
                        <h4>Venue: <?php echo $row['venueTitle'] ? $row['venueTitle'] : "N/A" ?>
                            (<?php echo $row['make'] ?>)</h4>
                        <h4>Location: <?php echo $row['located'] ?></h4>
                        <h5>Ksh.<?php echo $row['venuePrice'] ?></h5>
                    </div>
                    <div class="ent">
                        <!-- Entertainment Crew -->
                        <h2>Entertainment Crew</h2>
                        <h4><?php echo $row['entTitle'] ?></h4>
                        <h4><?php echo $row['deejay'] ?> & <?php echo $row['mc'] ?></h4>
                        <h5>Ksh.<?php echo $row['entPrice'] ?></h5>

                    </div>
                    <div class="amount">
                        <!-- Total Price -->
                        <h2>Total Price</h2>

                        <h3>Ksh.<?php echo $row['eventPrice']+$row['entPrice']+ $row['venuePrice']; ?></h3>
                    </div>
                </div>

            </div>
            <div class="right">
                <!-- Payment Form -->

                <h2>LIPA NA</h2>
                <img src="./assets/mpesa.png">
                <form method="POST" action="">
                    <?php if(@$_GET['response']):?>
                    <p class="success"><?php echo @$_GET['response'] ?></p>
                    <?php elseif(@$_GET['response']):?>
                    <p class="error"><?php echo @$_GET['response'] ?></p>
                    <?php endif ?>
                    <label for="">Amount</label>
                    <input type="text" readonly name="amount" value="<?php echo $row['eventPrice']+$row['entPrice']+$row['venuePrice']; ?>" required>

                    <label for="">Phone Number</label>
                    <input type="text" name="phone" value="<?php echo $row['phoneNumber']; ?>" required>
                    <input hidden type="text" name="bookingId" value="<?php echo $_GET['id']; ?>" required>

                    <button class="btndark" name="pay" type="submit">PAY NOW</button>
                </form>

            </div>
            <?php endif ?>
        </div>
    </div>

</body>

</html>