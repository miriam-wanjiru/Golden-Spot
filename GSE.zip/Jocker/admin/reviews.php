<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Reviews";
    $getReviewQuery = "SELECT reviews.*,users.*, events.title AS eventTitle,venue.title AS venueTitle, entertainment.title AS entTitle, entertainment.deejay, entertainment.mc
        FROM reviews
        INNER JOIN events ON reviews.eventId = events.eventId
        INNER JOIN venue ON reviews.venueId = venue.venueId
        INNER JOIN users ON reviews.userId = users.userId
        INNER JOIN entertainment ON reviews.entId = entertainment.entId ";
    $reviews = $conn->query($getReviewQuery);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/venues.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <h1 class="pageTitle">Reviews</h1>
            <div class="venueContent">

                <table>
                    <thead>
                        <tr>
                            <th>Review-Id</th>
                        
                            <th>User</th>
                            <th>Review</th>
                            <th>Rating</th>
                            <th>Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $reviews->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['reviewId'] ?></td>
                           
                            <td><?= $row['firstname'] ?> <?= $row['lastname']?></td>
                            <td><?= $row['review'] ?></td>
                            <td><?= $row['rating'] ?> Stars</td>
                            <td>
                                <a class="btn" style="color: <?= $row['approved'] == 1 ? 'red' : 'green' ?>"
                                    href="./approveReview.php?id=<?= $row['reviewId'] ?>&src=reviews&to=<?= $row['approved'] == 1 ? 'Disapprove' : 'Approve' ?>">
                                    <?php echo $row['approved'] == 1 ? 'Disapprove' : 'Approve' ?>
                                </a>
                            </td>

                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

            </div>

        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>