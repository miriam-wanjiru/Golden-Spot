<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot";
    $userCountQuery = "SELECT COUNT(*) as allUsers FROM users";
    $users = $conn->query($userCountQuery); 
     $venuesCountQuery = "SELECT COUNT(*) as allVenues FROM venue";
    $venues = $conn->query($venuesCountQuery); 
     $eventsCountQuery = "SELECT COUNT(*) as allEvents FROM events";
    $eventss = $conn->query($eventsCountQuery); 
     $entCountQuery = "SELECT COUNT(*) as allEnts FROM entertainment";
    $entCrew = $conn->query($entCountQuery); 
    $bookingsCountQuery = "SELECT COUNT(*) as allBookings FROM bookings";
    $bookings = $conn->query($bookingsCountQuery); 
     $reviewsQuery = "SELECT COUNT(*) as allReviews FROM reviews";
    $reviews = $conn->query($reviewsQuery); 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/dash.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <h1 class="pageTitle">Dashboard</h1>
            <div class="dashboard">
                <div class="dashCard">
                    <h2>Users</h2>
                    <?php @$users && $countUser = @$users->fetch_assoc(); ?>
                    <h1 class="itemNum"><?= $countUser['allUsers'] ?></h1>
                    <a href="./users.php" class="btndark">VIEW</a>
                </div>
                <div class="dashCard">
                    <h2>Venues</h1>
                        <?php @$venues && $countVenue = @$venues->fetch_assoc(); ?>
                        <h1 class="itemNum"><?= $countVenue['allVenues'] ?></h1>
                        <a href="./venues.php" class="btndark">VIEW</a>
                </div>
                <div class="dashCard">
                    <h2>Bookings</h2>
                    <?php @$bookings && $countBookings = @$bookings->fetch_assoc(); ?>
                    <h1 class="itemNum"><?= $countBookings['allBookings'] ?></h1>
                    <a href="./bookings.php" class="btndark">VIEW</a>
                </div>
                <div class="dashCard">
                    <?php @$eventss && $countEvents = @$eventss->fetch_assoc(); ?>
                    <h2>Events</h2>
                    <h1 class="itemNum"><?= $countEvents['allEvents'] ?></h1>
                    <a href="./events.php" class="btndark">VIEW</a>
                </div>
                <div class="dashCard">
                    <h2>Ent-Crews</h2>
                    <?php @$entCrew && $countEnts = @$entCrew->fetch_assoc(); ?>
                    <h1 class="itemNum"><?= $countEnts['allEnts'] ?></h1>
                    <a href="./entertainment.php" class="btndark">VIEW</a>
                </div>
                <div class="dashCard">
                    <h2>Reviews</h2>
                    <?php @$reviews && $countReviews = @$reviews->fetch_assoc(); ?>
                    <h1 class="itemNum"><?= $countReviews['allReviews'] ?></h1>
                    <a href="./reviews.php" class="btndark">VIEW</a>
                </div>
            </div>
        </div>
    </div>

</body>
<script src="./js/main.js"></script>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>