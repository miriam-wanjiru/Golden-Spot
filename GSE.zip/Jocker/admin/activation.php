<?php
session_start();
include('../dbconnection.php');

if($_SESSION['loggedUser']) {
    if($_GET['id'] && $_GET['src'] && $_GET['to']) {
       
        if($_GET['to'] == 'Deactivate') {
            // deactivate ent crew
            if($_GET['src'] == 'entertainment') { 
                $id = $_GET['id'];
                $query = "UPDATE entertainment SET isActive = 0 WHERE entId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Deactivated!");
</script>
<?php
                    header("location:entertainment.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
                // deactivate venue
            } elseif($_GET['src'] == 'venue'){
                $id = $_GET['id'];
                $query = "UPDATE venue SET isActive = 0 WHERE venueId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Deactivated!");
</script>
<?php
                    header("location:venues.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
            }
              // deactivate event
            elseif($_GET['src'] == 'event'){
                $id = $_GET['id'];
                $query = "UPDATE events SET isActive = 0 WHERE eventId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Deactivated!");
</script>
<?php
                    header("location:events.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
            }
        } elseif($_GET['to'] == 'Activate') {
            // activate ent crew
             if($_GET['src'] == 'entertainment') {
                $id = $_GET['id'];
                $query = "UPDATE entertainment SET isActive = 1 WHERE entId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Activated!");
</script>
<?php
                    header("location:entertainment.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
                // activate venue
            } elseif($_GET['src'] == 'venue'){
                $id = $_GET['id'];
                $query = "UPDATE venue SET isActive = 1 WHERE venueId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Deactivated!");
</script>
<?php
                    header("location:venues.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
                // Activate Event
            }elseif($_GET['src'] == 'event'){
                $id = $_GET['id'];
                $query = "UPDATE events SET isActive = 1 WHERE eventId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Deactivated!");
</script>
<?php
                    header("location:events.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
            }
        }
    }
} else {
    header("location:index.php");
}
?>