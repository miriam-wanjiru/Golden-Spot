<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Events";
    if(isset($_POST['add'])){
        $eventTitle = $_POST['eventTitle'];
        $eventPrice = $_POST['eventPrice'];
        $eventDesc = $_POST['eventDesc'];
        $eventStatus = $_POST['eventStatus'];

        $filename = $_FILES["coverImage"]["name"];
        $tempname = $_FILES["coverImage"]["tmp_name"];
        $folder = "./uploads/" . $filename;
        
        if (move_uploaded_file($tempname, $folder)) {
        $AddEventQuery =  "INSERT INTO events (title, descriptions, price, coverImage, isActive)
        VALUES ('$eventTitle','$eventDesc', $eventPrice, '$filename',$eventStatus)";
         $result = $conn->query($AddEventQuery);
        if ($result == TRUE) {
        ?><script>
alert("Event Added Successfully!")
</script><?php
    }else{
         ?><script>
alert("An Error occured.!")
</script><?php
    }
        }
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/event.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="eventContent">

                <div class="topBar">
                    <h1 class="pageTitle">Add Event</h1>
                    <a href="./events.php" class="btndark">View Events</a>
                </div>

                <div>
                    <form method="POST" action="addEvents.php" enctype="multipart/form-data">
                        <label>
                            Title
                        </label>
                        <input type=" text" name="eventTitle" placeholder="Title" required>
                        <label>
                            Price
                        </label>
                        <input type="number" name="eventPrice" placeholder="Price" required>
                        <label>
                            Cover Image
                        </label>
                        <input type="file" name="coverImage" placeholder="Cover Image" required>
                        <label>
                            Description
                        </label>
                        <textarea cols="8" rows="8" name="eventDesc"
                            placeholder="Write a brief descriptions for your clients..." required></textarea>
                        <label>
                            Status
                        </label>
                        <select name="eventStatus" id="" required>
                            <option>Choose</option>
                            <option value="1">Active</option>
                            <option value="2">Inactive</option>
                        </select>
                        <button type="submit" name="add" class="btndark">ADD EVENT</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>