<?php
session_start();
include('../dbconnection.php');

if($_SESSION['loggedUser']) {
    if($_GET['id'] && $_GET['src'] && $_GET['to']) {
        
        if($_GET['to'] == 'Delete') {
            if($_GET['src'] == 'entertainment') {
                $id = $_GET['id'];
                $query = "DELETE FROM entertainment  WHERE entId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Deleted!");
</script>
<?php
                    header("location:entertainment.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
            }elseif($_GET['src'] == 'venue'){
                $id = $_GET['id'];
                $query = "DELETE FROM venue  WHERE venueId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Deleted!");
</script>
<?php
                    header("location:venues.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
            }elseif($_GET['src'] == 'event'){
                $id = $_GET['id'];
                $query = "DELETE FROM events  WHERE eventId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Deleted!");
</script>
<?php
                    header("location:events.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
            }
        } 
    }
} else {
    header("location:index.php");
}
?>