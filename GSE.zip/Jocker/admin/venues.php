<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Venues";
    $getVenueQuery =  "SELECT * FROM venue";
    $venues = $conn->query($getVenueQuery);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/venues.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="venueContent">
                <div class="topBar">
                    <h1 class="pageTitle">Venues</h1>
                    <a href="./addVenues.php" class="btndark">Add Venues</a>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Venue ID</th>
                            <th>Title</th>
                            <th>Location</th>
                            <th>Type</th>
                            <th>Capacity</th>
                            <th>price</th>
                            <th>Status</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $venues->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['venueId'] ?></td>
                            <td><?= $row['title'] ?></td>
                            <td><?= $row['located'] ?></td>
                            <td><?= $row['make'] ?></td>
                            <td><?= $row['capacity'] ?> People</td>
                            <td>Ksh.<?= $row['price'] ?></td>
                            <td>
                                <a class="btn" style="color: <?= $row['isActive'] == 1 ? 'red' : 'green' ?>"
                                    href="./activation.php?id=<?= $row['venueId'] ?>&src=venue&to=<?= $row['isActive'] == 1 ? 'Deactivate' : 'Activate' ?>">
                                    <?= $row['isActive'] == 1 ? 'Deactivate-It' : 'Activate-It' ?>
                                </a>
                            </td>
                            <td>
                                <a class="btn" style="color: orange; ?>"
                                    href="./editVenue.php?id=<?= $row['venueId'] ?>">
                                    Edit
                                </a>
                            </td>
                            <td><a class="btn" style="color: red; ?>"
                                    href="./delete.php?id=<?= $row['venueId'] ?>&src=venue&to=Delete">
                                    Delete
                                </a></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

            </div>

        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>