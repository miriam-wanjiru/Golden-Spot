<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Entertainment";
    if(isset($_POST['add'])){
        $title = $_POST['entTitle'];
        $deejay = $_POST['entDj'];
        $mc = $_POST['entMc'];
        $price = $_POST['eventPrice'];
        $status = $_POST['eventStatus'];

        $entAddQuery =  "INSERT INTO entertainment (title, deejay, mc, price, isActive) VALUES ('$title','$deejay','$mc','$price','$status')";
           $result = $conn->query($entAddQuery);
            if ($result === TRUE) {
        ?><script>
alert("Ent Crew Added Successfully!")
</script><?php
    }else{
         ?><script>
alert("An Error occured.!")
</script><?php
    }

    }



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/event.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="eventContent">

                <div class="topBar">
                    <h1 class="pageTitle">Add Ent Crew</h1>
                    <a href="./entertainment.php" class="btndark">View Ent Crews</a>
                </div>

                <div>
                    <form method="POST" action="addEntertainment.php">
                        <label>
                            Title
                        </label>
                        <input type="text" name="entTitle" placeholder="Title" required>
                        <label>
                            Deejay
                        </label>
                        <input type="text" name="entDj" placeholder="Deejay Name" required>
                        <label>
                            Mc
                        </label>
                        <input type="text" name="entMc" placeholder="Mc Name" required>
                        <label>
                            Price
                        </label>
                        <input type="number" name="eventPrice" placeholder="Price" required>

                        <label>
                            Status
                        </label>
                        <select name="eventStatus" id="" required>
                            <option>Choose</option>
                            <option selected value="1">Active</option>
                            <option value="2">Inactive</option>
                        </select>
                        <button type="submit" name="add" class="btndark">ADD EVENT</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>