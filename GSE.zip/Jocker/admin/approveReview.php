<?php
session_start();
include('../dbconnection.php');

if($_SESSION['loggedUser']) {
    if($_GET['id']){
    if($_GET['to'] == 'Approve'){
                        $reviewId = $_GET['id'];
        $query = "UPDATE reviews SET approved=1 WHERE reviewId = $reviewId";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Approved!");
</script>
<?php
                    header("location:reviews.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
   }else{
               $reviewId = $_GET['id'];
        $query = "UPDATE reviews SET approved=0 WHERE reviewId = $reviewId";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Disapproved!");
</script>
<?php
                    header("location:reviews.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
    }
}
}
?>