<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Events";

     // GETTING SINGLE VENUE
      if(@$_GET['id']){
        $id = $_GET['id'];
        $getEventsQuery =  "SELECT * FROM events WHERE eventId = $id";
        @$events = $conn->query($getEventsQuery);
    }
    
    if(isset($_POST['updateEvent'])){
        $eventTitle = $_POST['eventTitle'];
        $eventPrice = $_POST['eventPrice'];
        $eventDesc = $_POST['eventDesc'];
        $eventStatus = $_POST['eventStatus'];
        $eid = $_POST['eid'];

        $filename = $_FILES["coverImage"]["name"];
        $tempname = $_FILES["coverImage"]["tmp_name"];
        $folder = "./uploads/" . $filename;
        
        if (move_uploaded_file($tempname, $folder)) {
        $editEventQuery =  "UPDATE events SET title='$eventTitle', descriptions='$eventDesc', price=$eventPrice, coverImage='$filename', isActive=$eventStatus WHERE eventId=$eid";
         $result = $conn->query($editEventQuery);
        if ($result == TRUE) {
        ?><script>
alert("Event Updated Successfully!")
</script><?php
    }else{
         ?><script>
alert("An Error occured.!")
</script><?php
    }
        }
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/event.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="eventContent">

                <div class="topBar">
                    <h1 class="pageTitle">Update Event</h1>
                    <a href="./events.php" class="btndark">View Events</a>
                </div>

                <div>
                    <?php @$events && $row = @$events->fetch_assoc(); ?>
                    <form method="POST" action="editEvent.php" enctype="multipart/form-data">
                        <input type="number" name="eid" value="<?= @$row['eventId'] ?>" hidden required>
                        <label>
                            Title
                        </label>
                        <input type=" text" name="eventTitle" placeholder="Title" value="<?= @$row['title'] ?>"
                            required>
                        <label>
                            Price
                        </label>
                        <input type="number" name="eventPrice" placeholder="Price" value="<?= @$row['price'] ?>"
                            required>
                        <label>
                            Cover Image
                        </label>
                        <img src="./uploads/<?= @$row['coverImage'] ?>" height="120px" width="120px" alt="" srcset="">
                        <input type="file" name="coverImage" placeholder="Cover Image" required>
                        <label>
                            Description
                        </label>
                        <textarea cols="8" rows="8" name="eventDesc"
                            placeholder="Write a brief descriptions for your clients..."
                            required><?= @$row['descriptions'] ?></textarea>
                        <label>
                            Status
                        </label>
                        <select name="eventStatus" id="" required>
                            <option value="1">Active</option>
                            <option value="2">Inactive</option>
                        </select>
                        <button type="submit" name="updateEvent" class="btndark">UPDATE EVENT</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>