<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    
    $_SESSION['title'] = "Golden Spot - Bookings";
    $getBookingQuery =  "SELECT bookings.*, events.coverImage, events.title AS eventTitle,events.price AS eventPrice, events.coverImage, venue.price AS venuePrice,venue.title AS venueTitle, venue.located, venue.make, venue.capacity, users.phoneNumber, entertainment.title AS entTitle, entertainment.price AS entPrice, entertainment.deejay, entertainment.mc
        FROM bookings
        INNER JOIN events ON bookings.eventId = events.eventId
        INNER JOIN venue ON bookings.venueId = venue.venueId
        INNER JOIN users ON bookings.userId = users.userId
        INNER JOIN entertainment ON bookings.entId = entertainment.entId ";
    $bookings = $conn->query($getBookingQuery);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/dash.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="bookingContent">
                <h1 class="pageTitle">Bookings</h1>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Title</th>
                        <th>Price</th>
                        <th>Payment</th>
                        <th>Action</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($bookings):
                     while ($row = $bookings->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $row['bookingId'] ?></td>
                        <td><?= $row['eventTitle'] ?></td>
                        <td>Ksh.<?php echo $row['eventPrice']+$row['entPrice']+ $row['venuePrice']; ?></td>

                        <td style="color: <?= $row['isPaid'] == 1 ? 'green' : 'red' ?>">
                            <?= $row['isPaid'] == 1 ? 'Paid' : 'Not Paid' ?>

                        </td>
                        <td><a class="btn" style="color: orangered; ?>"
                                href="./updateBooking.php?id=<?= $row['bookingId'] ?>">
                                Update </a></td>
                        <td><a class="btn" style="color: blue; ?>"
                                href="./bookingDetails.php?id=<?= $row['bookingId'] ?>">
                                View Details </a></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php endif ?>


        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>