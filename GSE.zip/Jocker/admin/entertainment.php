<?php 
    session_start();
    include('../dbconnection.php');
    $_SESSION['title'] = "Golden Spot - Entertainment";
    $getEntQuery =  "SELECT * FROM entertainment";
    $ents = $conn->query($getEntQuery);
    if($_SESSION['loggedUser']){

    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/dash.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="bookingContent">
                <div class="topBar">
                    <h1 class="pageTitle">Entertainment</h1>
                    <a href="./addEntertainment.php" class="btndark">Add Ent Crew</a>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Ent-ID</th>
                        <th>Title</th>
                        <th>Deejay</th>
                        <th>MC</th>
                        <th>price</th>
                        <th>Status</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $ents->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['entId'] ?></td>
                        <td><?= $row['title'] ?></td>
                        <td><?= $row['deejay'] ?></td>
                        <td><?= $row['mc'] ?></td>
                        <td>Ksh.<?= $row['price'] ?></td>
                        <td>
                            <a class="btn" style="color: <?= $row['isActive'] == 1 ? 'red' : 'green' ?>"
                                href="./activation.php?id=<?= $row['entId'] ?>&src=entertainment&to=<?= $row['isActive'] == 1 ? 'Deactivate' : 'Activate' ?>">
                                <?= $row['isActive'] == 1 ? 'Deactivate-It' : 'Activate-It' ?>
                            </a>
                        </td>
                        <td>
                            <a class="btn" style="color: orange; ?>"
                                href="./editEntertainment.php?id=<?= $row['entId'] ?>">
                                Edit
                            </a>
                        </td>
                        <td><a class="btn" style="color: red; ?>"
                                href="./delete.php?id=<?= $row['entId'] ?>&src=entertainment&to=Delete">
                                Delete
                            </a></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>