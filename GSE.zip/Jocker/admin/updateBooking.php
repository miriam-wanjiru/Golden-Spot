<?php 
    session_start();
    include('../dbconnection.php');
    
 if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Booking";
    $email = @$_SESSION['loggedUser'];
    @$bId = $_GET['id'];
    
    // Query to retrieve booking details
    $getBookingQuery =  "SELECT bookings.*,users.*, events.coverImage, events.title AS eventTitle,events.price AS eventPrice, events.coverImage, venue.price AS venuePrice,venue.title AS venueTitle, venue.located, venue.make, venue.capacity, users.phoneNumber, entertainment.title AS entTitle, entertainment.price AS entPrice, entertainment.deejay, entertainment.mc
        FROM bookings
        INNER JOIN events ON bookings.eventId = events.eventId
        INNER JOIN venue ON bookings.venueId = venue.venueId
        INNER JOIN users ON bookings.userId = users.userId
        INNER JOIN entertainment ON bookings.entId = entertainment.entId 
        WHERE bookings.bookingId = '$bId'";
   
    $bookings = $conn->query($getBookingQuery);
    
    $getVenueQuery =  "SELECT * FROM venue WHERE isActive = 1";
    $venues = $conn->query($getVenueQuery);
    $getEntQuery =  "SELECT * FROM entertainment WHERE isActive = 1";
    $entertainments = $conn->query($getEntQuery);

    if(isset($_POST['update'])){
        $bookingId = $_POST['bId'];
        $venueId = $_POST['venue'];
        $entertainmentId = $_POST['entertainment'];
        $themeColor = $_POST['theme'];
        $eventTime = date('Y-m-d', strtotime($_POST['period']));
        $info = $_POST['info'];
        $isPaid = $_POST['payStatus'];
        $mpesaRef = $_POST['mpesaRef'];
        @$bookingId = $_GET['id'];

        $updateQuery = "UPDATE bookings SET venueId='$venueId', entId='$entertainmentId', theme='$themeColor', eventTime='$eventTime', info='$info', isPaid=$isPaid, mpesaRef='$mpesaRef'  WHERE bookingId='$bookingId'";

        $updated = mysqli_query($conn, $updateQuery);

// Check if the query executed successfully
    if ($updated) {
    // Retrieve the auto-incremented bookingId
    header("location:./bookings.php");
    // echo $bookingId,  $venueId, $entertainmentId, $themeColor,  $eventTime,  $info,  $isPaid;
            // echo   $venueId;

} else {
    ?><script>
alert("Error Updating booking");
</script><?php
}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/updateBooking.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <?php if($booking = $bookings->fetch_assoc()): ?>
        <div class="mainContent">
            <div class="bookingContent">
                <h1 class="pageTitle">Update Booking</h1>
                <h2>ID #<?php echo $booking['bookingId'] ?></h2>
                <h2>Date: <?php echo $booking['eventTime'] ?></h2>
                <h2>Ksh.<?php echo $booking['eventPrice']+$booking['entPrice']+ $booking['venuePrice']; ?>
                </h2>
            </div>

            <div class="parent">
                <div class="info">
                    <div class="event">
                        <div>
                            <h2>Event Details</h2>
                            <h3>Event: <?php echo $booking['eventTitle'] ? $booking['eventTitle'] : "N/A" ?></h3>
                            <h4>Date: <?php echo $booking['eventTime']?></h4>
                            <h5>Ksh.<?php echo $booking['eventPrice'] ?></h5>
                        </div>

                        <div class="venue">
                            <!-- Venue Details -->
                            <h2>Venue Details</h2>
                            <h4>Venue: <?php echo $booking['venueTitle'] ? $booking['venueTitle'] : "N/A" ?>
                                (<?php echo $booking['make'] ?>)</h4>
                            <h4>Location: <?php echo $booking['located'] ?></h4>
                            <h5>Ksh.<?php echo $booking['venuePrice'] ?></h5>
                        </div>
                    </div>

                    <div class="ent">
                        <!-- Entertainment Crew -->
                        <h2>Entertainment Crew</h2>
                        <h4><?php echo $booking['entTitle'] ?></h4>
                        <h4><?php echo $booking['deejay'] ?> & <?php echo $booking['mc'] ?></h4>
                        <h5>Ksh.<?php echo $booking['entPrice'] ?></h5>

                    </div>

                </div>

                <div class="form">

                    <form action="" method="POST">
                        <input hidden type="text" value="<?php echo @$bId ?>" name="bId">

                        <label>
                            Payment Status
                        </label>
                        <select name="payStatus" id="" required>
                            <option value=""></option>

                            <option <?php echo $booking['isPaid'] == 1 ? "selected" : ""; ?> value="1">Paid</option>
                            <option <?php echo $booking['isPaid'] == 0 ? "selected" : ""; ?> value="0">Not Paid</option>

                        </select>
                        <label>Receipt</label>
                        <input type="text" required placeholder="Mpesa Receipt" name="mpesaRef">
                        <label>
                            Choose Venue
                        </label>
                        <select name="venue" id="" required>
                            <option value=""></option>
                            <?php while ($row = $venues->fetch_assoc()): ?>
                            <option selected="<?php $row['venueId'] == $booking['venueId'] ? "selected" : "" ?>" value="
                                <?php echo $row['venueId']?>">
                                <?php echo $row['title'] . " (". $row['make'] . ") in " . $row['located']. " for Ksh." . $row['price'] ; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        <label>
                            Choose Entertainment
                        </label>
                        <select name="entertainment" id="" required>
                            <option value=""></option>
                            <?php while ($row = $entertainments->fetch_assoc()): ?>
                            <option selected="<?php $row['entId'] == $booking['entId'] ? "selected" : "" ?>"
                                value="<?php echo $row['entId']?>">
                                <?php echo $row['deejay'] . " and " . $row['mc']. " from " . $row['title'] . " for Ksh." . $row['price'] ; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                        <label>Date</label>
                        <input type="date" name="period" value="<?php echo $booking['eventTime'] ?>"
                            min="<?php echo date('Y-m-d'); ?>" placeholder="Color" id="" required>
                        <label>Event Theme Color</label>
                        <div class="colorInfo">
                            <div class="theme" style="background: <?php echo $booking['theme'] ?>;">
                                <?php echo $booking['theme'] ?>
                            </div>
                            <div class="picker"> <input class="color" type="color" name="theme" placeholder="Color"
                                    id="" required>
                            </div>

                        </div> <label>
                            Message
                        </label>
                        <textarea cols="8" rows="4" name="info" placeholder="Write a massage for the Admin..."
                            required><?php echo $booking['info']; ?></textarea>
                        <div class="action">
                            <button type="submit" name="update" class="btndark">UPDATE</button>
                            <a class="btndark" href="./bookings.php">Bookings</a>
                        </div>
                    </form>

                </div>
            </div>
            <?php endif ?>
        </div>

</body>

</html>
<?php }else{
    header('location: ./login.php');
} ?>