  <?php 
  ?>
  <div class="sidebar">
      <div class="menuItems">
          <a class="" href="./dashboard.php">Dashboard</a>

          <a class="" href="./users.php">Users</a>

          <a class="" href="./events.php">Events</a>

          <a class="" href="./venues.php">Venues</a>

          <a class="" href="./bookings.php">Bookings</a>

          <a class="" href="./reviews.php">Reviews</a>

          <a class="" href="./entertainment.php">Entertainment</a>
      </div>
  </div>