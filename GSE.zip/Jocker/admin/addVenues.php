<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Venues";

    if(isset($_POST['add'])){
        $venueTitle = $_POST['venueTitle'];
        $venueLocation = $_POST['venueLocation'];
        $venueCapacity = $_POST['venueCapacity'];
        $venueMake = $_POST['venueMake'];
        $venuePrice = $_POST['venuePrice'];
        $venueStatus = $_POST['venueStatus'];

        $addVenueQuery = "INSERT INTO venue (title,located,make,capacity,price,isActive)
        VALUES ('$venueTitle', '$venueLocation','$venueMake',$venueCapacity, $venuePrice,$venueStatus)";
        $result = $conn->query($addVenueQuery);
        if ($result === TRUE) {
        ?><script>
alert("Venue Added Successfully!")
</script><?php
    }else{
         ?><script>
alert("An Error occured.!")
</script><?php
    }
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/event.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="eventContent">

                <div class="topBar">
                    <h1 class="pageTitle">Add Venue</h1>
                    <a href="./venues.php" class="btndark">View Venues</a>
                </div>

                <div>
                    <form method="POST" action="addVenues.php">
                        <label>
                            Title
                        </label>
                        <input type="text" name="venueTitle" placeholder="Title" required>
                        <label>
                            Location
                        </label>
                        <input type="text" name="venueLocation" placeholder="Location" required>
                        <label>
                            Capacity
                        </label>
                        <input type="number" name="venueCapacity" placeholder="Capacity" required>
                        <label>
                            Price
                        </label>
                        <input type="number" name="venuePrice" placeholder="Price" required>
                        <label>
                            Type
                        </label>
                        <select name="venueMake" id="" required>
                            <option>Choose</option>
                            <option value="indoors">Indoors</option>
                            <option value="outdoors">Outdoors</option>
                            <option value="N/A">N/A</option>
                        </select>
                        <label>
                            Status
                        </label>
                        <select name="venueStatus" id="" required>
                            <option>Choose</option>
                            <option value="1">Active</option>
                            <option value="2">Inactive</option>
                        </select>
                        <button type="submit" name="add" class="btndark">ADD VENUE</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>