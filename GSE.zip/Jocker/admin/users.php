<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){

    $_SESSION['title'] = "Golden Spot - Users";
    $getUserQuery =  "SELECT * FROM users";
    $users = $conn->query($getUserQuery);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/dash.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="usersContent">
                <div class="topBar">
                    <h1 class="pageTitle">Registered Users</h1>
                </div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>FirstName</th>
                        <th>LastName</th>
                        <th>email</th>
                        <th>Phone-No</th>
                        <th>Approved?</th>
                        <th>Admin?</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $users->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['userId'] ?></td>
                        <td><?= $row['firstname'] ?></td>
                        <td><?= $row['lastname'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['phoneNumber'] ?></td>
                        <td>
                            <a class="btn" style="color: <?= $row['isApproved'] == 1 ? 'red' : 'green' ?>"
                                href="./approve.php?id=<?= $row['userId'] ?>&to=<?= $row['isApproved'] == 1 ? 'Disapprove' : 'Approve' ?>">
                                <?= $row['isApproved'] == 1 ? 'Disapprove Acc' : 'Approve Acc' ?>
                            </a>
                        </td>
                        <td>
                            <a class="btn" style="color: <?= $row['isAdmin'] == 1 ? 'red' : 'green' ?>"
                                href="./changeRank.php?id=<?= $row['userId']?>&to=<?= $row['isAdmin'] == 1 ? 'Demote' : 'Promote' ?>">
                                <?= $row['isAdmin'] == 1 ? 'Remove Admin' : 'Make Admin' ?>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>