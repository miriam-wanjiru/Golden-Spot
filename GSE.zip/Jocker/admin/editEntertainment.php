<?php 

    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Entertainment";
    
    // GETTING SINGLE ENT CREW
      if(@$_GET['id']){
        $id = $_GET['id'];
        $getEntQuery =  "SELECT * FROM entertainment WHERE entId = $id";
        @$ents = $conn->query($getEntQuery);}
         
    if(isset($_POST['updateEnt'])){
        $title = $_POST['entTitle'];
        $deejay = $_POST['entDj'];
        $mc = $_POST['entMc'];
        $price = $_POST['eventPrice'];
        $status = $_POST['eventStatus'];
        $editId = $_POST['eid'];

       $entUpdateQuery = "UPDATE entertainment SET title='$title', deejay='$deejay', mc='$mc', price=$price, isActive=$status WHERE entId=$editId";

           $result = $conn->query($entUpdateQuery);
            if ($result == TRUE) {
        ?><script>
alert("Ent Crew Updated Successfully!")
</script><?php
 header("location:entertainment.php");
    }else{
         ?><script>
alert("An Error occured.!")
</script><?php
    }

    }
    


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/event.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="eventContent">

                <div class="topBar">
                    <h1 class="pageTitle">Update Ent Crew</h1>
                    <a href="./entertainment.php" class="btndark">View Ent Crews</a>
                </div>

                <div>
                    <?php @$ents && $row = @$ents->fetch_assoc(); ?>
                    <form method="POST" action="editEntertainment.php">
                        <input type="text" name="eid" value="<?= @$row['entId'] ?>" hidden required>
                        <label>
                            Title
                        </label>
                        <input type="text" name="entTitle" placeholder="Title" value="<?= @$row['title'] ?>" required>
                        <label>
                            Deejay
                        </label>
                        <input type="text" name="entDj" placeholder="Deejay Name" value="<?= @$row['deejay'] ?>"
                            required>
                        <label>
                            Mc
                        </label>
                        <input type="text" name="entMc" placeholder="Mc Name" value="<?= @$row['mc'] ?>" required>
                        <label>
                            Price
                        </label>
                        <input type="number" name="eventPrice" placeholder="Price" value="<?= @$row['price'] ?>"
                            required>

                        <label>
                            Status
                        </label>
                        <select name="eventStatus" id="" required>

                            <option value="1">Active</option>
                            <option value="2">Inactive</option>
                        </select>
                        <button type="submit" name="updateEnt" class="btndark">UPDATE EVENT</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>