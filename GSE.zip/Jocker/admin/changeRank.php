<?php
session_start();
include('../dbconnection.php');

if($_SESSION['loggedUser']) {
    if($_GET['id']){
    if($_GET['to'] == 'Promote'){
                        $id = $_GET['id'];
        $query = "UPDATE users SET isAdmin=1 WHERE userId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Promoted!");
</script>
<?php
                    header("location:users.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
   }else{
                    $id = $_GET['id'];
       $query = "UPDATE users SET isAdmin=0 WHERE userId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Demoted!");
</script>
<?php
                    header("location:users.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
    }
}
}
?>