<?php 
    session_start();
    include('../dbconnection.php');
    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Events";
    $getEventQuery =  "SELECT * FROM events";
    $events = $conn->query($getEventQuery);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/event.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="container">
        <?php include "./sidebar.php";?>
        <div class="mainContent">
            <div class="eventContent">

                <div class="topBar">
                    <h1 class="pageTitle">Events</h1>
                    <a href="./addEvents.php" class="btndark">Add Events</a>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Event ID</th>
                            <th>Cover Image</th>
                            <th>Title</th>
                            <th>Price</th>
                            <th>Description</th>
                            
                            <th>Status</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $events->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['eventId'] ?></td>
                            <td><img height="70px" width="70px" src="./uploads/<?= $row['coverImage']?>" alt=""
                                    srcset=""></td>
                            <td><?= $row['title'] ?></td>
                            <td>Ksh.<?= $row['price'] ?></td>
                            <td style="text-align:left;">

                                <p><?php echo $row['descriptions']; ?></p>

                            </td>
                       
                            <td>
                                <a class="btn" style="color: <?= $row['isActive'] == 1 ? 'red' : 'green' ?>"
                                    href="./activation.php?id=<?= $row['eventId'] ?>&src=event&to=<?= $row['isActive'] == 1 ? 'Deactivate' : 'Activate' ?>">
                                    <?= $row['isActive'] == 1 ? 'Deactivate' : 'Activate' ?>
                                </a>
                            </td>
                            <td>
                                <a class="btn" style="color: orange; ?>"
                                    href="./editEvent.php?id=<?= $row['eventId'] ?>">
                                    Edit
                                </a>
                            </td>
                            <td><a class="btn" style="color: red; ?>"
                                    href="./delete.php?id=<?= $row['eventId'] ?>&src=event&to=Delete">
                                    Delete
                                </a></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

</body>

</html>
<?php 
    }else{
         header("location:index.php");
    }
    ?>