<?php
session_start();
include('../dbconnection.php');

if($_SESSION['loggedUser']) {
    if($_GET['id']){
    if($_GET['to'] == 'Approve'){
                        $id = $_GET['id'];
        $query = "UPDATE users SET isApproved=1 WHERE userId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Approved!");
</script>
<?php
                    header("location:users.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
   }else{
                    $id = $_GET['id'];
       $query = "UPDATE users SET isApproved=0 WHERE userId = $id";
                $result = $conn->query($query);

                if($result) {
                    ?>
<script>
alert("Disapproved!");
</script>
<?php
                    header("location:users.php");
                } else {
                    ?>
<script>
alert("An error occurred!");
</script>
<?php 
                }
    }
}
}
?>