<?php 
session_start();
include('../dbconnection.php');

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $loginQuery = "SELECT * FROM users WHERE email = '$email' AND password = '$password' AND isApproved = 1 AND isAdmin = 1";
    $result = $conn->query($loginQuery);
    if ($result->num_rows === 1) {
        ?><script>
alert("Logged-In Successfully!")
</script><?php
        $_SESSION['loggedUser'] = $email;
        header("location:dashboard.php");
    }else{
         ?><script>
alert("Not Logged-In!")
</script><?php
    }

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin-Login</title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/login.css">
</head>

<body>
    <div class="container">
        <form class="login-form" method="POST" action="index.php">
            <h2>ADMIN-LOGIN</h2>
            <input type="email" placeholder="Email Address" name='email' required>
            <input type="password" placeholder="Password" name="password" required>
            <button type="submit" name="login">Log In</button>
        </form>
    </div>
</body>

</html>