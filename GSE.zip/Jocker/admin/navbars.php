  <nav class="navbar">
      <h2 class="logo">Golden-Spot Events - Admin</h2>
      <div class="cta">
          <h4 class="loggedUser">Welcome, <?php echo $_SESSION['loggedUser'];?></h4>
          <a href="./logout.php" class="btn">Logout</a>
      </div>
  </nav>