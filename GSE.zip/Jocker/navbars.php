<nav class="navbar">
    <h1 class="logo">G S E</h1>
    <div class="menu">
        
        <?php 
            if(@$_SESSION['loggedUser']){
        ?>
        <a class="" href="./">Welcome</a>
        <a class="" href="./bookings.php">Bookings</a>
        <a class="" href="./account.php">Account</a>
        <?php }?>
    </div>
    <div class="cta">
        <?php if(@$_SESSION['loggedUser']){?>
        <h4 class="loggedUser">Welcome, <?php echo $_SESSION['loggedUser'];?></h4>
        <a href="./logout.php" class="btn">Logout</a>
        <?php }else{ ?>
        <a href="./signup.php" class="btn">CREATE ACCOUNT</a>
        <a href="./login.php" class="btn">LOGIN</a>
        <?php } ?>
    </div>
</nav>