<?php 
    session_start();
    include('./dbconnection.php');
    
 if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Booking";
    $email = @$_SESSION['loggedUser'];
    $bId = $_GET['id'];
    
    // Query to retrieve booking details
    $getBookingQuery =  "SELECT bookings.*,users.*, events.coverImage, events.title AS eventTitle,events.price AS eventPrice, events.coverImage, venue.price AS venuePrice,venue.title AS venueTitle, venue.located, venue.make, venue.capacity, users.phoneNumber, entertainment.title AS entTitle, entertainment.price AS entPrice, entertainment.deejay, entertainment.mc
        FROM bookings
        INNER JOIN events ON bookings.eventId = events.eventId
        INNER JOIN venue ON bookings.venueId = venue.venueId
        INNER JOIN users ON bookings.userId = users.userId
        INNER JOIN entertainment ON bookings.entId = entertainment.entId 
        WHERE bookings.bookingId = '$bId'";
    $bookings = $conn->query($getBookingQuery);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/bookings.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="mainContainer">
        <div class="parent">
            <?php if($bookings): ?>
            <h1>Booking Details</h1>
            <?php if($row = $bookings->fetch_assoc()): ?>
            <div class="top">
                <a href="./bookings.php" class="btndark">View Bookings</a>

                <div class="topright"><?php if($row['isPaid'] == 0): ?>
                    <a class="btndark" href="./checkout.php?id=<?php echo $row['bookingId'] ?>">Pay</a>
                    <?php else: ?>
                    <h2 style="color: green;">PAID</h2>

                    <?php endif ?>
                    <button OnClick="CallPrint(this.value)" href="./bookings.php" class="btndark">Generate
                        Report</button>
                </div>
            </div>
            <section id="report">
                <caption>
                    <h2>Booking ID #
                        <?php echo $row['bookingId'] ?></h2>
                    <h4>Mpesa Ref: <?php echo $row["mpesaRef"] ? $row['mpesaRef'] : "N/A";?></h4>
                </caption>
                <table border="1">
                    <tbody>
                        <tr>
                            <th colspan="6">Customer Details</th>
                        </tr>
                        <tr>
                            <th>Name</th>
                            <td><?php echo $row['firstname']?> <?php echo $row['lastname']?></td>
                            <th>Contact no.</th>
                            <td><?php echo $row['phoneNumber']?></td>
                            <th>Email </th>
                            <td><?php echo $row['email']?></td>
                        </tr>
                        <tr>

                            <th>Booking Date</th>
                            <td><?php echo $row['bookedOn']?></td>
                            <th>Event Date</th>
                            <td colspan="3"><?php echo $row['eventTime']?></td>
                        </tr>
                        <tr>
                            <td colspan="6"></td>
                        </tr>
                        <tr>
                            <th colspan="6">Event Details</th>
                        </tr>
                        <tr>
                            <th>Event</th>
                            <th>Venue</th>
                            <th>Entertainment</th>
                            <th colspan="3">Message</th>

                        </tr>

                        <tr>
                            <td><?php echo $row['eventTitle'];?></td>
                            <td><?php echo $row['venueTitle']?>(<?php echo $row['located'] ?>)</td>
                            <td><?php echo $row['entTitle']?>(<?php echo $row['deejay']?> & <?php echo $row['mc']?>)
                            </td>
                            <td colspan="3" rowspan="2">
                                <?php echo $row['info'];?>
                            </td>

                        </tr>
                        <tr>
                            <td>Ksh.<?php echo $row['eventPrice'];?></td>
                            <td>Ksh.<?php echo $row['venuePrice']?></td>
                            <td>Ksh.<?php echo $row['entPrice']?></td>


                        </tr>


                        <tr>
                            <th rowspan="2">Theme</th>
                            <td rowspan="2" style="background: <?php echo $row['theme'];?>">
                                <?php echo $row['theme'];?>
                            </td>
                            <th rowspan="2" style="text-align:center">Grand Total</th>
                            <td rowspan="1" colspan="2">
                                Ksh.<?php echo $row['eventPrice']+$row['entPrice']+ $row['venuePrice']; ?>
                            </td>
                            <td colspan="3" style="color: <?= $row['isPaid'] == 1 ? 'green' : 'red' ?>">
                                <?= $row['isPaid'] == 1 ? 'Paid' : 'Not Paid' ?>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </section>

            <?php endif; ?>
            <?php endif ?>
        </div>
    </div>

    <script>
    function CallPrint(strid) {
        var prtContent = document.getElementById("report");
        var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
        WinPrint.document.write(prtContent.innerHTML);
        WinPrint.document.close();
        WinPrint.focus();
        WinPrint.print();
        WinPrint.close();
    }
    </script>

</body>

</html>
<?php }else{
    header('location: ./login.php');
} ?>