<?php 
    session_start();
    include('./dbconnection.php');
    include('config.php');

    $_SESSION['title'] = "Golden Spot - Add Review";
    $bId = $_GET['id'];
    $email = @$_SESSION['loggedUser'];

    // Query to retrieve booking details
    $getBookingQuery =  "SELECT bookings.*, events.coverImage, events.title AS eventTitle,events.price AS eventPrice, events.coverImage, venue.price AS venuePrice,venue.title AS venueTitle, venue.located, venue.make, venue.capacity, users.phoneNumber, entertainment.title AS entTitle, entertainment.price AS entPrice, entertainment.deejay, entertainment.mc
        FROM bookings
        INNER JOIN events ON bookings.eventId = events.eventId
        INNER JOIN venue ON bookings.venueId = venue.venueId
        INNER JOIN users ON bookings.userId = users.userId
        INNER JOIN entertainment ON bookings.entId = entertainment.entId 
        WHERE bookingId = '$bId'";
    $booking = $conn->query($getBookingQuery);

    if($booking) {

        // Query to retrieve user ID from email
        $userQ =  "SELECT userId FROM users WHERE email = '$email'";
        $result = mysqli_query($conn, $userQ);
    }

        if(isset($_POST['Add'])){
            $userId = $_POST['userId'];
            $bookingId = $_POST['bookingId'];
            $review = $_POST['review'];
            $rating = $_POST['rating'];
            $eventId = $_POST['eventId'];
            $venueId = $_POST['venueId'];
            $entId = $_POST['entId'];
            $approved= 0;

            $addReviewQuery = "INSERT INTO reviews(bookingId,userId,eventId,venueId,entId,review,rating,approved)VALUES('$bookingId','$userId','$eventId','$venueId','$entId','$review','$rating','$approved')";
            $added = mysqli_query($conn, $addReviewQuery);
            if($added){
                header("location:addReview.php?id=$bookingId&success=Review Added Waiting for Approval");
            }else{
                header("location:addReview.php?id=$bookingId&error=An error occured. Try Again!");
            }

      
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/review.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="mainContainer">
        <div class="parent">
            <?php if($booking):
                    $row = $booking->fetch_assoc() ?>
            <div class="left">
                <span>
                    <h1>Review</h1>
                    <h2>Booking ID #<?php echo $_GET['id']; ?></h2>
                </span>

                <!-- Event Details -->


                <div class="wrapper">
                    <div class="imgContainer">
                        <img src="./admin/uploads/<?php echo $row['coverImage'] ?>" alt="">
                    </div>
                    <div class="event">
                        <h2>Event Details</h2>
                        <h3>Event: <?php echo $row['eventTitle'] ? $row['eventTitle'] : "N/A" ?></h3>
                        <h4>Date: <?php echo $row['eventTime']?></h4>
                        <h5>Ksh.<?php echo $row['eventPrice'] ?></h5>
                    </div>
                    <div class="venue">
                        <!-- Venue Details -->
                        <h2>Venue Details</h2>
                        <h4>Venue: <?php echo $row['venueTitle'] ? $row['venueTitle'] : "N/A" ?>
                            (<?php echo $row['make'] ?>)</h4>
                        <h4>Location: <?php echo $row['located'] ?></h4>
                        <h5>Ksh.<?php echo $row['venuePrice'] ?></h5>
                    </div>
                    <div class="ent">
                        <!-- Entertainment Crew -->
                        <h2>Entertainment Crew</h2>
                        <h4><?php echo $row['entTitle'] ?></h4>
                        <h4><?php echo $row['deejay'] ?> & <?php echo $row['mc'] ?></h4>
                        <h5>Ksh.<?php echo $row['entPrice'] ?></h5>

                    </div>
                    <div class="amount">
                        <!-- Total Price -->
                        <h2>Total Price</h2>

                        <h3>Ksh.<?php echo $row['eventPrice']+$row['entPrice']+ $row['venuePrice']; ?></h3>
                    </div>
                    <div style="color:green">
                        <h1>PAID</h1>
                        <h4>#<?php echo $row['mpesaRef'] ;?></h4>
                    </div>
                </div>

            </div>
            <div class="right">
                <!-- Payment Form -->

                <h2>Add Review</h2>

                <form method="POST">
                    <?php if(@$_GET['success']):?>
                    <p class="success"><?php echo @$_GET['success'] ?></p>
                    <?php elseif(@$_GET['error']):?>
                    <p class="error"><?php echo @$_GET['error'] ?></p>
                    <?php endif ?>
                    <?php $user = $result->fetch_assoc() ?>
                    <input hidden type="text" name="userId" value="<?php echo $user['userId'];?>" id="">
                    <input hidden type="text" name="bookingId" id="" value="<?php echo $_GET['id']; ?>">

                    <input hidden type="text" value="<?php echo $row['entId']?>" name="entId">
                    <input hidden type="text" value="<?php echo $row['venueId']?>" name="venueId">
                    <input hidden type="text" value="<?php echo $row['eventId']?>" name="eventId">
                    <label for="">Review</label>
                    <textarea required name="review" placeholder="Write Review..." id="" cols="30" rows="10"></textarea>

                    <label for="">Rating</label>
                    <select name="rating" id="" required>
                        <option value=""></option>
                        <option value="1">1 star</option>
                        <option value="2">2 star</option>
                        <option value="3">3 star</option>
                        <option value="4">4 star</option>
                        <option value="5">5 star</option>
                    </select>

                    <button class="btndark" name="Add" type="submit">Review</button>
                </form>

            </div>
            <?php endif ?>
        </div>
    </div>

</body>

</html>