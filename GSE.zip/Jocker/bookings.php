<?php 
    session_start();
    include('./dbconnection.php');

    if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Bookings";
    $email = @$_SESSION['loggedUser'];

    $userQ =  "SELECT userId FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $userQ);
    $user = $result->fetch_assoc();
    $uId = $user['userId'];
    
    // Query to retrieve booking details
    $getBookingQuery =  "SELECT bookings.*, events.coverImage, events.title AS eventTitle,events.price AS eventPrice, venue.price AS venuePrice,venue.title AS venueTitle, venue.located, venue.make, venue.capacity, users.phoneNumber, entertainment.title AS entTitle, entertainment.price AS entPrice, entertainment.deejay, entertainment.mc
        FROM bookings
        INNER JOIN events ON bookings.eventId = events.eventId
        INNER JOIN venue ON bookings.venueId = venue.venueId
        INNER JOIN users ON bookings.userId = users.userId
        INNER JOIN entertainment ON bookings.entId = entertainment.entId 
        WHERE bookings.userId = '$uId'";
    $bookings = $conn->query($getBookingQuery);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/bookings.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="mainContainer">

        <div class="parent">
            <h2>Booking History</h2>


            <table>
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Title</th>
                        <th>Price</th>
                        <th>Payment</th>
                        <th>Details</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($bookings):
                     while ($row = $bookings->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $row['bookingId'] ?></td>
                        <td><?= $row['eventTitle'] ?></td>
                        <td>Ksh.<?php echo $row['eventPrice']+$row['entPrice']+ $row['venuePrice']; ?></td>

                        <td style="color: <?= $row['isPaid'] == 1 ? 'green' : 'red' ?>">
                            <?= $row['isPaid'] == 1 ? 'Paid' : 'Not Paid' ?>

                        </td>
                        <td>
                            <a class="btndark" style="color: slate; ?>"
                                href="./bookingDetails.php?id=<?= $row['bookingId'] ?>">
                                View Details </a>
                        </td>
                        <td> <?php if($row['isPaid']== 1):?><a class="btndark" style="color: slate; ?>"
                                href="./addReview.php?id=<?= $row['bookingId'] ?>">
                                Add Review</a>
                            <?php else: ?>
                            <a class="btndark" href="./checkout.php?id=<?php echo $row['bookingId'] ?>">Pay</a>
                            <?php endif ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php endif ?>

        </div>

    </div>

</body>

</html>
<?php }else{
    header('location: ./login.php');
} ?>