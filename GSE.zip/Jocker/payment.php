<?php
   // include_once './kaari/Admin/dbConnection.php';
    include('config.php');
    
    session_start();
    //$amount=$_SESSION['mpesaAmount'];

    if(isset($_POST['pay'])){
       $phoneNum = $_POST['phoneNum'];
       $amount = $_POST['amount'];
        
       $url="https://tinypesa.com/api/v1/express/initialize";
       $data = array(
           'amount' => $amount ,
           'msisdn' => $phoneNum,
           'account_no'=> $phoneNum,
       );
       $headers = array(
          "Content-Type: application/x-www-form-urlencoded",
          "ApiKey: ". API_KEY .""
       );
       $options = array(
           'http' => array(
               'header'  => $headers,
               'method'  => 'POST',
               'content' => http_build_query($data)
           )
       );
   
       $context  = stream_context_create($options);
       $resp = file_get_contents($url, true, $context);
       if($resp){
        ?> <script>
alert("Check an STK Push has been sent to your phone.");
</script><?php
       }
   header("location: bookings.php");

    }
?>