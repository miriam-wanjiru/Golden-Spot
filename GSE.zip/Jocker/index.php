<?php 
    session_start();
    include('./dbconnection.php');
    // if($_SESSION['loggedUser']){
    $_SESSION['title'] = "Golden Spot - Home";
    $getEventQuery =  "SELECT * FROM events WHERE isActive = 1";
    $events = $conn->query($getEventQuery);
    $getVenueQuery =  "SELECT * FROM venue WHERE isActive = 1";
    $venues = $conn->query($getVenueQuery);
    

    $getReviewsQuery = "SELECT reviews.*,users.*, events.title AS eventTitle,venue.title AS venueTitle, entertainment.title AS entTitle, entertainment.deejay, entertainment.mc
        FROM reviews
        INNER JOIN events ON reviews.eventId = events.eventId
        INNER JOIN venue ON reviews.venueId = venue.venueId
        INNER JOIN users ON reviews.userId = users.userId
        INNER JOIN entertainment ON reviews.entId = entertainment.entId 
        WHERE reviews.approved = 1";
    $reviews = $conn->query($getReviewsQuery);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['title'];?></title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/home.css">

</head>

<body>
    <?php include "./navbars.php"?>
    <div class="mainContainer">
        <div class="heading">
            <h1>Golden Spot Events</h1>
        </div>

        <div class="picContainer">
            <div class="picOverlay"></div>
            <img src="./assets/mainpic.jpg" alt="">
        </div>
        <div class="cardRow">

            <?php while ($row = $events->fetch_assoc()): ?>
            <div class="card">
                <img src="./admin/uploads/<?= $row['coverImage'] ?>" height="250px" width="380px" alt="">
                <div class="title"><?= $row['title'] ?></div>
                <div class="cardDetails">
                    <h2 class="price"><span>(Venues & Entertainment Excluded)</span><br>Ksh.<?= $row['price'] ?>
                    </h2>
                    <a class="btndark" href="./eventDetails.php?id=<?= $row['eventId'] ?>">Book Event</a>
                </div>
            </div>

            <?php endwhile; ?>
        </div>
        <div class="review">
            <div class="reviewDesc">
                <h1>Reviews</h1>
            </div>
            <?php while ($review = $reviews->fetch_assoc()): ?>

            <div class="reviewCard">
                <div class="top">
                    <h2><?php echo $review['firstname'] ?> <?php echo $review['lastname'] ?></h2>
                    <h3><?php echo $review['eventTitle'] ?> at <?php echo $review['venueTitle'] ?>
                        with <?php echo $review['entTitle'] ?></h3>
                    <h4>
                        Rating: <?php echo $review['rating'] ?> Stars
                    </h4>
                </div>
                <div class="message">
                    <p> <?php echo $review['review'];?></p>
                </div>
            </div>
            <?php endwhile; ?>

        </div>
        <div class="availableVenues">
            <div class="venueDesc">
                <h1>Our Venues</h1>
            </div>
            <div class="venueSection">
                <?php while ($row = $venues->fetch_assoc()): ?>
                <div class="venueCard">
                    <div class="venueDetails">
                        <h2 class="title"><?= $row['title'] ?></h2>
                        <p><?= $row['located'] ?></p>
                        <p>(<?php echo $row['make']?>)</p>
                        <p><?php echo $row['capacity'] < 1 ? "" : $row['capacity'] ."People" ?></p>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>

    </div>


</body>

</html>
<!-- <?php 
    // }else{
    //      header("location:index.php");
    // }
    ?> -->