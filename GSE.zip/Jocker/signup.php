<?php 
session_start();
include('./dbconnection.php');

if(isset($_POST['signup'])){
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = md5($_POST['password']);
    $confirmPassword = md5($_POST['confirmPassword']);
    $isApproved = 1;
    $isAdmin = 0;

    if($password == $confirmPassword){


    $signupQuery = "INSERT INTO users(firstname, lastname, email, phoneNumber, password,isApproved,isAdmin)VALUES('$firstname','$lastname','$email','$phone','$password',$isApproved,$isAdmin)";
    $result = $conn->query($signupQuery);
    if ($result) {
        ?><script>
alert("Signed-Up Successfully!")
</script><?php
        header("location:login.php");
    }else{
         ?><script>
alert("Not Signed-Up!")
</script><?php
    }
    }else{
         ?><script>
alert("Passwords do not Match!")
</script><?php
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Golden Spot - Signup</title>
    <link rel="stylesheet" href="./css/common.css">
    <link rel="stylesheet" href="./css/signup.css">

</head>

<body>
    <div class="main">
        <div class="cover"><img src="./assets/event.jpg" alt="" srcset=""></div>
        <form class="signup-form" method="POST" action="signup.php">
            <h2>GOLDEN SPOT EVENTS SIGN UP</h2>
            <label for="">First Name</label>
            <input type="text" placeholder="First Name" name='firstname' required>
            <label for="">Last Name</label>
            <input type="text" placeholder="Last Name" name='lastname' required>
            <label for="">Email Address</label>
            <input type="email" placeholder="Email Address" name='email' required>
            <label for="">Phone Number</label>
            <input type="text" placeholder="Phone Number" name='phone' required>
            <label for="">Password</label>
            <input min="6" type="password" min="6" placeholder="Password" name="password" min="6" required>
            <label for="">Confirm Password</label>
            <input min="6" type="password" min="6" placeholder="Confirm Password" name="confirmPassword" required>
            <button type="submit" name="signup">Create Account</button>
            <p>Have an account ? <a href="./login.php">Login</a></p>
        </form>
    </div>
</body>

</html>